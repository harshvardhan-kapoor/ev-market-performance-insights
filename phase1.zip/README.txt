EV Market Performance & Insights — filled college template pack

Student: Harshvardhan Kapoor (individual project)
Team ID: No team
Faculty mentor: Not assigned / not provided
Dataset URL: https://www.kaggle.com/datasets/tharishreddy22/electric-vehicle-market-classification-dataset
Uploaded Project.csv equivalence: unverified; confirm before final submission.

Important: items requiring real screenshots, live performance measurements, Snowflake evidence, formal user interviews, or verified analytical findings are explicitly marked pending/unverified. Do not submit these as completed evidence without performing the checks. Original PDF templates are included with SOURCE_ prefixes; filled companion DOCX notes are provided where PDF editing was not appropriate.

Project links:
GitHub: https://github.com/harshvardhan-kapoor/ev-market-performance-insights
Live app: https://ev-market-performance-insights-ihn4.onrender.com/
Tableau Story: https://public.tableau.com/views/ElectricVehicleMarketPerformanceInsights_17931290853150/Story1?:showVizHome=no&:language=en-US
